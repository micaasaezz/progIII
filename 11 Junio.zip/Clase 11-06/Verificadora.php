<?php
 class Verificadora implements IMiddleware
 {
    function VerificarUsuario($request,$response,$next);
    {
        public static function ValidarUsuario($request, $response, $next)
        {    
            if($request->isGet())
            {
                $response->getBody()->write("<br>El request de grupo es un GET");
            }
            else if ($request->isPost())
            {
                $respuestasArray = $request->GetParsedBody();
        
                require_once("AccesoDatos.php");
        
                $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
                $consulta = $objetoAccesoDato->RetornarConsulta("SELECT * FROM usuario where
                                                                 id=:id and
                                                                 nombre=:nombre and
                                                                 clave=:clave and
                                                                 clave=:perfil");
                $id = $respuestasArray["id"]; 
                $perfil = $respuestasArray["perfil"]; 
                $clave = $respuestasArray["clave"];
                $nombre = $respuestasArray["nombre"];
                $consulta->bindParam(":id", $clave, PDO::PARAM_INT);
                $consulta->bindParam(":nombre", $clave, PDO::PARAM_STR);
                $consulta->bindParam(":clave", $clave, PDO::PARAM_STR);
                $consulta->bindParam(":perfil", $nombre, PDO::PARAM_STR);
                $consulta->Execute();
                $usuarios = $consulta->Fetch();
                
                if ($usuarios > 0) 
                {
                    $response->getBody()->write("<br>Bienvenidx ". $nombre);  
                    $response->getBody()->write("<br>El request de grupo es un POST");
                    return $next($request,$response);
                }else
                {
                    $response->getBody()->write("<br>Sin permiso/no registrado en base de datos");
                }
                /*if($respuestasArray["perfil"] == "admin")
                {
                    $response->getBody()->write("<br>Bienvenidx ". $respuestasArray["nombre"]);  
                    $response->getBody()->write("<br>El request de grupo es un POST");  
                }
                else
                {
                    $response->getBody()->write("<br>Sin permiso");
                }*/
            }
            
            return $response;
        }
    }
 }
?>