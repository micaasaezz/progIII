<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

require_once './vendor/autoload.php';
require_once 'Verificadora.php';

$app = new \Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>GET");
    return $response;

});

$app->add(Verificadora::ValidarUsuario($request, $response, $next) {    
 
});

$app->put('/param', function (Request $request, Response $response) {    
 
});


$app->group('/credenciales', function () {

      
})->add(\Usuario::class."::ValidarUsuario");



$app->run();


?>