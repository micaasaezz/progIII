<?php
require "IMiddleware.php";
class Verificadora implements IMiddleware
{
    public static function VerificarUsuario($request, $response, $next)
    {
        if($request->isGet())
        {
            $response->getBody()->write("<br>El request es un GET");
            return $next($request,$response);
        }
        else
        {
            $respuestasArray = $request->GetParsedBody();
        
            require_once("AccesoDatos.php");
            $objetoAccesoDato = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', "root", "");
            $consulta = $objetoAccesoDato->prepare("SELECT * FROM usuarios".
                                            "WHERE nombre=:nombre and clave=:clave");
            
            $nombre = $respuestasArray["nombre"];
            $clave = $respuestasArray["clave"];
            /*$consulta->bindParam(":nombre", $nombre, PDO::PARAM_STR);
            $consulta->bindParam(":clave", $clave, PDO::PARAM_STR);*/
            
            $consulta->Execute(array("nombre"=>$nombre,"clave"=>$clave));

            if ($consulta->rowCount() ==1) 
            {
                $response->getBody()->write("<br>Bienvenidx ". $nombre);  
                $response->getBody()->write("<br>El request es un POST");
                return $next($request,$response);
            }
            else
            {
                $response->getBody()->write("<br>Sin permiso/no registrado en base de datos");
            }

        }
        return $response;
    }
}
?>