<?php

use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

require_once './vendor/autoload.php';
require_once 'Verificadora.php';

echo '<html><body><form method="POST"><input type="text" name="nombre" id="txtNombre"/></br><input type="text" name="clave" id="txtClave"/><input type="submit"/></form></body></html>';

$app = new \Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>GET");
    return $response;
});

$app->post('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>POST");
    return $response;
});
$app->put('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>PUT");
    return $response;
});
$app->delete('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>DELETE");
    return $response;
});

$app->add(\Verificadora::class."::VerificarUsuario");


$app->run();
/*
- get       muestra todos los cds de la tabla

si el usuario esta registrado en la database
- post      inserta un cd en la bd
- delete    elimina el cd  
            capa anterior para verificar si es superadmin             
- put      

put y delete usan el encabezado xml form uncoded
post form-data


*/

?>