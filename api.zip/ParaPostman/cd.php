<?php
include_once "AccesoDatos.php";
class Cd
{
    public $titulo;
    public $interprete;
    public $anio;

    public function __construct($titulo="",$interprete="",$anio=0)
    {
        $this->titulo = $titulo;
        $this->interprete = $interprete;
        $this->anio = $anio;
    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into cds (titulo, interprete, anio)
        values (:titulo,:interprete,:anio)");
        $consulta->bindValue(':titulo',$this->titulo,PDO::PARAM_STR);
        $consulta->bindValue(':interprete',$this->interprete,PDO::PARAM_STR);
        $consulta->bindValue(':anio',$this->anio, PDO::PARAM_INT);
        		
        return $consulta->execute();
    }

    public function Eliminar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("DELETE from cds 
        WHERE titulo=:titulo and interprete=:interprete and anio=:anio");	
        $consulta->bindValue(':interprete',$this->interprete, PDO::PARAM_STR);
        $consulta->bindValue(':titulo',$this->titulo, PDO::PARAM_STR);
        $consulta->bindValue(':anio',$this->anio, PDO::PARAM_INT);
        $consulta->execute();
        
		return $consulta->rowCount();
    }

    public function Modificar()
	{
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("UPDATE usuarios set
        	interprete='$this->interprete', titulo='$this->titulo', anio='$this->anio'
            WHERE id='$this->id'");
            
		return $consulta->execute();
    }

    public static function TraerTodos()
	{
    	$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from cds");
        $consulta->execute();			
            
		return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }
    
    public function TraerUno()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from cds 
        where interprete='$this->interprete' and titulo='$this->titulo' and anio='$this->anio'");
		$consulta->execute();			

        return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

    public static function TraerPorID($id)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from cds where id='$id'");
		$consulta->execute();			
        
        return $consulta->SetFetchMode(PDO::FETCH_INTO, new Cd);
	}
}