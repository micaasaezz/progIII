<?php
    
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once "./vendor/autoload.php";
    require_once "./usuario.php";
    use \Firebase\JWT\JWT as JWT;

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;
  
    $app = new \Slim\App(["settings" => $config]);

    $app->group('/usuario', function ()
    {
        /*$this->post('/verificarUsuario', function ($request, $response) 
        {
            $datos = $request->getParsedbody();
            $token = $datos["token"];
            
            if(empty($token) || $token === "")
            {
                throw new Exception("El token esta vacio!");
            }

            try{
                $decodificado = JWT::decode(
                    $token,
                    "miClaveSecreta",
                    ["HS256"]
                );
                
                return $response->withJson("Token valido", 200);          
            }
            catch(Exception $e){
                throw new Exception("Token no valido!!");
            }
        });*/

        $this->post('/agregarUsuario', function ($request, $response) 
        {
            $datos = $request->getParsedbody();
            
            $apellido = $datos["apellido"];
            $nombre = $datos["nombre"];
            $clave = $datos["clave"];
            $mail = $datos["email"];
            $legajo = $datos["legajo"];
            $perfil = $datos["perfil"];
            $email = $datos["email"];
            $foto = $datos["foto"];

            $obj = new Usuario($nombre, $apellido, $legajo, $email, $perfil, $foto, $clave);
            if($obj->TraerUno() == null)                 
            {
                $usuario = $obj->Agregar();
                $payload = array(
                    "email" => $email,
                    "clave" => $clave,
                    "nombre" => $nombre,
                    "apellido" => $apellido,
                    "foto" => $foto,
                    "perfil" => $perfil,
                    "legajo" => $legajo
                );
                $token = JWT::encode($payload,"miClaveSecreta");
                $response->getBody()->write("Usuario agregado ");
                return $response->withJson($token, 200);
            }   
            else
            {
                return $response->withJson("Usuario ya registrado", 200);
            }          
            
        });
        $this->put('/modificarUsuario', function ($request, $response) {
            $datos = $request->getParsedbody();
            $apellido = $datos["apellido"];
            $nombre = $datos["nombre"];
            $clave = $datos["clave"];
            $mail = $datos["email"];
            $legajo = $datos["legajo"];
            $perfil = $datos["perfil"];
            $email = $datos["email"];
            $foto = $datos["foto"];

            $obj = new Usuario($nombre, $apellido, $legajo, $email, $perfil, $foto, $clave);
            if($obj->TraerUno() != null)                 
            {
                $response->getBody()->write("Elemento modificado ");

                return $response->withJson($obj->Modificar(), 200);
            }   
            else
            {
                return $response->withJson("No existe ese usuario para modificar", 200);
            }                      
        })->add(\Verificadora::class."::VerificarToken");

        $this->put('/eliminarUsuario', function ($request, $response) {
            $datos = $request->getParsedbody();
            $legajo = $datos["legajo"]; 

            $obj = new Usuario("", "", $legajo, "", "", "", "");
            $usuario = $obj->TraerUno();
            if($usuario != null)                 
            {
                if($usuario->Eliminar() > 1)
                {
                    return "Elemento eliminado";
                }
                else
                {
                    return "No se elimino";
                }   
            }   
            else
            {
                return $response->withJson("No existe ese usuario para eliminar", 200);
            }         
        })->add(\Verificadora::class."::VerificarToken");

        $this->put('/listarCD', function ($request, $response) {
            
            return $response->withJson(Usuario::TraerTodos(), 200);                
        })->add(\Verificadora::class."::VerificarToken");
        
    });
    
    
    $app->group('/cd', function ()
    {
        $this->post('/agregarCD', function ($request, $response) 
        {
            $datos = $request->getParsedbody();
            $titulo = $datos["titulo"];
            $cantante = $datos["cantante"];
            $anio = $datos["anio"];
            
            $obj = new Cd($titulo, $interprete, $anio);
                
            $response->getBody()->write("Elemento agregado ");    
            return $response->withJson($obj->Agregar(), 200);

        });
        $this->put('/modificarCD', function ($request, $response) {
            $datos = $request->getParsedbody();
            $titulo = $datos["titulo"];
            $cantante = $datos["cantante"];
            $anio = $datos["anio"];   
            $id = $datos["id"];

            $cd = Cd::TreaerPorID($id);
            if($cd != null)                 
            {
                $cd->titulo = $titulo;
                $cd->interprete = $interprete;
                $cd->anio = $anio;
                    
                $response->getBody()->write("Elemento modificado ");
                return $response->withJson($cd->Modificar(), 200);    
            }   
            else
            {
                return $response->withJson("No existe ese cd para modificar", 200);
            }                       
            
        });
        $this->put('/eliminarCD', function ($request, $response) {
            $datos = $request->getParsedbody();
            $titulo = $datos["titulo"];
            $cantante = $datos["cantante"];
            $anio = $datos["anio"];   

            $cd = new Clase($titulo, $interprete, $anio);
            
            if($cd->Eliminar() > 1)
            {
                return "Elemento eliminado";
            }
            else
            {
                return "No se elimino";
            }                
            
        });
        $this->put('/listarCD', function ($request, $response) {
            
            return $response->withJson(Cd::TraerTodos(), 200);                
        });

    })->add(\Verificadora::class."::VerificarToken");

    $app->run();
?>