<?php
include_once "AccesoDatos.php";
class Usuario
{
    public $nombre;
    public $apellido;
    public $legajo;
    public $foto;
    public $email;
    public $clave;
    public $perfil;

    public function __construct($nombre="",$apellido="",$legajo=0,$email="",$perfil="",$foto="",$clave="")
    {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->legajo = $legajo;
        $this->email = $email;
        $this->perfil = $perfil;
        $this->foto = $foto;
        $this->clave = $clave;
    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuarios 
        (nombre, apellido, legajo, email, perfil, foto, clave)
        values (:nombre,:apellido,:legajo,:email,:perfil,:foto,:clave)");
        $consulta->bindValue(':nombre',$this->nombre,PDO::PARAM_STR);
        $consulta->bindValue(':apellido',$this->apellido,PDO::PARAM_STR);
        $consulta->bindValue(':legajo',$this->legajo, PDO::PARAM_INT);
        $consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
        $consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
        $consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
        $consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }

    public function Eliminar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("DELETE from usuarios WHERE legajo=:legajo");	
        $consulta->bindValue(':legajo',$this->legajo, PDO::PARAM_STR);
		$consulta->execute();
		return $consulta->rowCount();
    }

    public function Modificar()
	{
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("UPDATE usuarios set
        	nombre='$this->nombre', apellido='$this->apellido', legajo='$this->legajo', email='$this->email',
            perfil='$this->perfil', foto='$this->foto', clave='$this->clave'
			WHERE legajo='$this->legajo'");
		return $consulta->execute();

    }
    public static function TraerTodos()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }
    
    public function TraerUno()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios where legajo='$this->legajo'");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

    public static function TraerPorID($id)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios where legajo='$id'");
		$consulta->execute();			
		return $consulta->SetFetchMode(PDO::FETCH_INTO, new Usuario);
	}


}







?>