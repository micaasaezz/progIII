<?php
class Verificadora 
{
    public static function VerificarToken($request, $response, $next)
    {
        $datos = $request->GetParsedBody();
        
        $token = $datos["token"];

        if(empty($token) || $token === "")
        {
            throw new Exception("El token esta vacio!");
        }

        try{
            $decodificado = JWT::decode(
                $token,
                "miClaveSecreta",
                ["HS256"]
            );
            $response->getBody()->write("Bienvenidx ". $datos["nombre"]."<br>");
            return $next($request,$response);
        }
        catch(Exception $e){
            throw new Exception("Token no valido!!");
        }
    }
}
?>