<?php
   try {
        //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
        $usuario='root';
        $clave='';
        $objetoPDO = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', $usuario, $clave);

        //PARAM NOMBRADOS
        /*$id = 1;
        $sentencia = $objetoPDO->prepare("SELECT * FROM cds WHERE id=:id");
        $sentencia->bindParam(":id", $id, PDO::PARAM_INT);
        $sentencia->execute();
        var_dump($sentencia->fetch());*/

        //PARAMS POSISCIONADOS
        $id = 1;
        $sentencia = $objetoPDO->prepare("SELECT * FROM cds WHERE id=?");
        $sentencia->bindParam(4, $id, PDO::PARAM_INT);
        $sentencia->execute();
        var_dump($sentencia->fetch());
        
        
    } catch (PDOException $e) {

        echo "Error!!!\n" . $e->getMessage();
    }


?>