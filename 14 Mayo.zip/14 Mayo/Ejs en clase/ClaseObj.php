<?php
class CD
{
    public $titulo;
    public $interprete;
    public $anio;

    public function MostrarCD()
    {
        return $this->titulo." - ".$this->interprete." - ".$this->anio;
    }

}

?>
