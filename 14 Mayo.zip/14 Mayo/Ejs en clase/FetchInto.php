<?php
try {
     //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
     $usuario='root';
     $clave='';
     $objetoPDO = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', $usuario, $clave);

     $sentencia = $objetoPDO->prepare("SELECT * FROM cds");
     include_once("./ClaseObj.php");
     $sentencia->SetFetchMode(PDO::FETCH_INTO, new CD);
     $sentencia->bindParam(":id", $id, PDO::PARAM_INT);
     $sentencia->bindColumn(1, $col1, PDO::PARAM_STR);
     $sentencia->bindColumn(2, $col2, PDO::PARAM_STR);
     $sentencia->bindColumn(3, $col3, PDO::PARAM_INT);
     $sentencia->bindColumn(4, $col4, PDO::PARAM_INT);     
     

     $sentencia->execute();
     echo "TITULO - INTERPRETE - AÑO - ID\n";
     while($obj = $sentencia->fetch())
     {
        echo $obj->MostrarCD()."\n";
     }
     
 } catch (PDOException $e) {

     echo "Error!!!\n" . $e->getMessage();
 }


?>
