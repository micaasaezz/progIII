<?php
   try {
        //CREO INSTANCIA DE PDO, INDICANDO ORIGEN DE DATOS, USUARIO Y CONTRASEÑA
        $usuario='root';
        $clave='';
        $objetoPDO = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', $usuario, $clave);


        $sentencia = $objetoPDO->prepare("SELECT * FROM cds WHERE id=:id");
        $sentencia->execute(array("id"=>4));
        var_dump($sentencia->fetch());
        
    } catch (PDOException $e) {

        echo "Error!!!\n" . $e->getMessage();
    }


?>