<html>
	<head>
		<title>Ejemplo de ALTA-LISTADO - con archivos -</title>

		<meta charset="UTF-8">
		
		<link href="./img/utnLogo.png" rel="icon" type="image/png" />

		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.4/css/bootstrap.min.css">
		<link rel="stylesheet" type="text/css" href="estilo.css">

	</head>
	<body>
		<h4><?php echo $mensaje; ?></h4>
		<a class="btn btn-info" href="index.html">Menu principal</a>
		<a class="btn btn-info" href="grilla.php">Listado</a>
	</body>
</html>
