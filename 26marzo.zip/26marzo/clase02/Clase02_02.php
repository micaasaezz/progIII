<?php 

	include "no_existe.php";

//		require "no_existe.php";

