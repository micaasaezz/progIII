<?php
include_once "FiguraGeometrica.php";
class Triangulo extends FiguraGeometrica
{
    private $_altura;
    private $_base;

    public function __construct($base, $alto)
    {
        parent :: __construct();
        $this->_altura = $alto;
        $this->_base = $base;
        $this->CalcularDatos();
    }

    protected function CalcularDatos()
    {
        $this->_superficie = $this->_base * $this->_altura;
        $this->_perimetro = sqrt(pow($this->_altura, 2)+ pow($this->_base /2, 2));
    }
    public function Dibujar()
    {
        //&nbsp para que escriba espacios
                
        $ret ="<div style='color:".$this->_color."'> </div>";
        $espacios = $this->_altura -1; 
        $asteriscos =1;
        for($i=0; $i< $this->_altura; $i++)
        {
            for($j=0; $j< $espacios; $j++)
            {
                $ret .= "&nbsp;&nbsp;";
            }
            $espacios-=1;
            
            for($j=0; $j<$asteriscos; $j++)
            {
                $ret .= "*";
            }
            $ret .= "<br>";
            $asteriscos+=2;
        }
        return $ret."</div>";
    }

    public function ToString()
    {
        echo parent :: ToString();
        echo "<br>";
        return $this->Dibujar();
    }




}

?>