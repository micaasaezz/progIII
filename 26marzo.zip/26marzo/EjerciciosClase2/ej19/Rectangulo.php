<?php
include_once "FiguraGeometrica.php";

class Rectangulo extends FiguraGeometrica
{
    private $_ladoDos;
    private $_ladoUno;

    public function __construct($ladoUno, $ladoDos)
    {
        parent :: __construct();
        $this->_ladoUno = $ladoUno;
        $this->_ladoDos = $ladoDos;
        $this->CalcularDatos();
    }

    protected function CalcularDatos()
    {
        $this->_perimetro = ($this->_ladoUno*2) + ($this->_ladoDos*2);
        $this->_superficie = $this->_ladoUno * $this->_ladoDos;
    }
    public function Dibujar()
    {
        $i;
        $j;
        $ret ="<div style='color:".$this->_color."'>";
        for($i=0; $i< $this->_ladoUno; $i++)
        {
            for($j=0; $j< $this->_ladoDos; $j++)
            {
                $ret .= "*";
            }
            $ret .= "<br>";
        }

        return $ret."</div>";
    }

    public function ToString()
    {
        echo parent :: ToString();
        echo "<br>";
        return $this->Dibujar();
    }




}

?>