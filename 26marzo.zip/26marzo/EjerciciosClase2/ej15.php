<?php
$i;
$j;
for($j=1; $j<5;$j++)
{
    Potenciar($j);
    echo "---<br>";
}
function Potenciar($numero)
{
    for($i=1; $i<5;$i++)
    {
        echo pow($numero, $i) . "<br>";
    }
     
}

?>