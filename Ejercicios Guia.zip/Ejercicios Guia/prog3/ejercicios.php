<?php
/*  EJ1
$nombre = "Micaela";
$apellido = "Saez";
echo $apellido . ", ".$nombre;
*/
/* EJ 2 y 3
$x = -3;
$y = 15;
echo $x;
echo "<br>".$y;
echo "<br>".($y+$x);
*/
/* EJ 4
$suma = 0;
$i = 1;
while(($suma+$i)<1000)
{
	$suma += $i;
	$i++;
	echo $suma . "<br>";
}
echo "fueron ". $i ." nums";
*/
/* EJ 5
$a = 5;
$b = 1;
$c = 5;

if(($a > $b && $a < $c) ||($a < $b && $a > $c))
	echo $a;
else if(($b > $a && $b < $c) ||($b < $a && $b > $c))
	echo $b;
else if (($c > $b && $c < $a) ||($c < $b && $c > $a))
	echo $c;
else 
	echo "No hay valor medio";
*/
/* EJ 6
$operador = '+';
$op1 = 60;
$op2 = 2;

switch ($operador) {
	case '+':
		echo $op1 + $op2;
		break;
	case '-':
		echo $op1 - $op2;
		break;
	case '*':
		echo $op1 * $op2;
		break;
	case '/':
		echo $op1 / $op2;
		break;
	default:
		echo "ERROR";
		break;
}
*/
/* EJ 7
echo date('d / m / Y');
if( date('d m') > "21 03" && date('d m') <"21 06")
	echo "<br>otoño";
else if(date('d m') > "21 06" && date('d m') <"21 09")
	echo "<br>invierno";
else if(date('d m') > "21 09" && date('d m') <"21 12")
	echo "<br>primavera";
else 
	echo "<br>verano";
*/


	// ARRAYS

/* EJ 9
$vec;
$i;
$suma= 0;
for($i=0; $i<5;$i++)
{
	$vec[$i] = rand(0, 100);
	$suma+= $vec[$i];
}

//echo "El promedio es ". ($suma/5);

if(($suma/5) > 6)
	echo "Mayor a 6";
else if(($suma/5) == 6)
	echo "Igual a 6";
else
	echo "Menor a 6";
*/ 
/* EJ 10
$vec;
$i;
$impar = 1;

for($i=0; $i<10; $i++)
{
	$vec[$i] = $impar;
	$impar+=2;
}

for ($i=0; $i < 10; $i++) { 
	echo $vec[$i] . "<br>";
}

echo "-------<br>";

$i = 0;
while($i < 10)
{
	echo $vec[$i] . "<br>";
	$i++;
}

echo "-------<br>";

foreach ($vec as $i) 
{
	echo $i . "<br>";
}
*/

/* EJ 11
$v[1]=90; $v[30]=7; $v['e']=99; $v['hola']= 'mundo';

foreach ($v as $i) 
{
	echo $i. "<br>";
}
*/
/* EJ 12
$i;
$lapicera[0] = array("color" => "rojo", "marca" => "filgo", "trazo" => "fino", "precio" => 30);
$lapicera[1] = array("color" => "verde", "marca" => "filgo", "trazo" => "grueso", "precio" => 40);
$lapicera[2] = array("color" => "gris", "marca" => "filgo", "trazo" => "doble", "precio" => 50);

for ($i=0; $i < 3 ; $i++) 
{ 
	//var_dump($lapicera[$i]);
	echo "COLOR: ". $lapicera[$i]["color"] ;
	echo "<br>MARCA: ". $lapicera[$i]["marca"] ;
	echo "<br>TRAZO: ". $lapicera[$i]["trazo"] ;
	echo "<br>PRECIO: ". $lapicera[$i]["precio"] ;
	echo "<br>----<br>";
}
*/
/*  EJ 13
$mascotas = array("Perro", "Gato", "Ratón", "Araña");
array_push($mascotas, "Mosca");

$nums = array("1986", "1996", "2015", "78", "86");
$lengs = array("php", "mysql", "html5", "typescript", "ajax");

$max = count($mascotas) + count($nums) + count($lengs);
$i;

/*$vec[0] = $mascotas[0];

for ($i=1; $i < count($mascotas); $i++) 
{ 
	array_push($vec, $mascotas[$i]);
}
for ($i=0; $i < count($nums); $i++) 
{ 
	array_push($vec, $nums[$i]);
}
for ($i=0; $i < count($lengs); $i++) 
{ 
	array_push($vec, $lengs[$i]);
}*//*
$vec = array_merge($mascotas, $nums, $lengs);
//if(count($vec) == $max)
//	echo "BIEN";
//else
//	echo "MAL";

foreach ($vec as $i) 
{
	echo $i. "<br>";
}

*/


?>

