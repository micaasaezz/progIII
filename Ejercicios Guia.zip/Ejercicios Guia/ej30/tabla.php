<?php
    if(isset($_GET["generarTabla"]))
    {
        $filas = $_GET["filas"];
        $columnas = $_GET["columnas"];
        
        echo "Ahi va" . "<br>";
        echo Tablear($filas,$columnas);
    }
    function Tablear($f, $c)
    {
        $html="<html><body><table border=\"3\">"
        for($i=0;$i<$f; $i++)
        {
            $html.= "<tr>";
            for($j=0;$j<$c; $j++)
            {
                $html.= "<td>";
                $html.= "</td>";
            }
            $html.= "</tr>";
        }
        $html.="</table></body></html>";
        return $html;
    }
?>
