<!doctype html>
<html>
    <body>
        <form action="tabla.php" method="get">
            <h2>FILAS</h2><br>
            <select name="filas">
                <option value="1" selected>1<option/>
                <option value="2">2<option/>
                <option value="3">3<option/>
                <option value="4">4<option/>
                <option value="5">5<option/>
            </select>
            <h2>COLUMNAS</h2><br>
            <select name="columnas">
                <option value="1" selected>1<option/>
                <option value="2">2<option/>
                <option value="3">3<option/>
                <option value="4">4<option/>
                <option value="5">5<option/>
            </select>
            <input type="submit" name="generarTabla" value="Generar tabla"/>
        </form>
    </body>
</html>