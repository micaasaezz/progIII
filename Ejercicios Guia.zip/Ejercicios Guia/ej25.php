<?php
    $file = fopen("Mis archivos\palabras.txt", "r");
    
    $contador1 = 0;
    $contador2 = 0;
    $contador3 = 0;
    $contador4 = 0;
    $contador4Mas = 0;

    while(!feof($file))
    {
        $var = fgets($file);
        
        $array = str_word_count($var, 1);

        for($i=0; $i< count($array); $i++)
        {
            switch(strlen($array[$i]))
            {
                case 1:
                    $contador1++;
                    break;
                case 2:
                    $contador2++;
                    break;
                case 3:
                    $contador3++;
                    break;
                case 4:
                    $contador4++;
                    break;
                default:
                    $contador4Mas++;
                    break;
                
                
            }
            
        }
        
    }  
    
    
/*  echo $contador1 . "<br>";
    echo $contador2 . "<br>";
    echo $contador3 . "<br>";
    echo $contador4 . "<br>";
    echo $contador4Mas . "<br>";
*/
?>
<!DOCTYPE html>
<html>
<head>
    
</head>
<body>
    <table border="1">
        <tr>
            <td>Una</td>
            <td>Dos</td>
            <td>Tres</td>
            <td>Cuatro</td>
            <td>Mas de 4</td>
        </tr>
        <tr>
            <td> <?php echo $contador1 ?></td>
            <td> <?php echo $contador2 ?></td>
            <td> <?php echo $contador3 ?></td>
            <td> <?php echo $contador4 ?></td>
            <td> <?php echo $contador4Mas ?></td>
        </tr>
    </table>
</body>
</html>