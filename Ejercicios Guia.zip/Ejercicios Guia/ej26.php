<!doctype HTML>
<html>
    <body>
        <input type="text" name="rutaArchivo" id="rutaArchivo"/>
        
    </body>    
</html>