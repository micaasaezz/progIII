<?php
include_once "AccesoDatos.php";
class Media
{
    public $color;
    public $marca;
    public $precio;
    public $talle;
    
    public function __construct($color,$marca,$precio,$talle)
    {
        $this->marca = $marca;
        $this->color = $color;
        $this->precio = $precio;
        $this->talle = $talle;
    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into medias 
        (color, marca, precio, talle)
        values (:color,:marca,:precio,:talle)");
        $consulta->bindValue(':color',$this->color,PDO::PARAM_STR);
        $consulta->bindValue(':marca',$this->marca,PDO::PARAM_STR);
        $consulta->bindValue(':precio',$this->precio, PDO::PARAM_INT);
        $consulta->bindValue(':talle', $this->talle, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }

    public static function TraerTodos()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from medias");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }
    
    public function TraerUno()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from medias where id='$this->id'");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_ASSOC);
	}

    public static function TraerPorEmailClave($email, $clave)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios where email='$email' and clave='$clave'");
		$consulta->execute();			
		return $consulta->SetFetchMode(PDO::FETCH_INTO, new Usuario);
	}


}







?>