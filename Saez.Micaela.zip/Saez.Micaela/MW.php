<?php
class MW 
{
    public function VerificarSeteados($request, $response, $next)
    {
        $datos = $request->GetParsedBody();

        if(!isset($datos["correo"]) && (!isset($datos["clave"])))
        {
            return $response->withJson("Ni el correo ni la clave estan seteados", 409);
        }
        else if(!isset($datos["correo"])) 
        {
            return $response->withJson("El correo no esta seteado", 409);
        }
        else if(!isset($datos["clave"]))
        {
            return $response->withJson("La clave no esta seteada", 409);    
        }
        else
        {
            return $next($request,$response);
        }
        
    }
    public static function VerificarVacios($request, $response, $next)
    {
        $datos = $request->GetParsedBody();
        $correo = $datos["correo"];
        $clave = $datos["clave"];

        if((empty($correo) || $correo === "") && (empty($clave) || $clave === ""))
        {
            return $response->withJson("El correo y la clave estan vacios", 409);
        }
        if(empty($correo) || $correo === "") 
        {
            return $response->withJson("El correo esta vacio", 409);
        }
        else if(empty($clave) || $clave === "")
        {
            return $response->withJson("La clave esta vacia", 409);    
        }
        else
        {
            return $next($request,$response);
        }
        
    }
    public function VerificarMailClave($request, $response, $next)
    {
        $datos = $request->GetParsedBody();
        
        $clave = $datos["clave"];
        $email = $datos["correo"];

        require_once "./usuario.php";
        $obj = Usuario::TraerPorEmailClave($email, $clave);
        if($obj != null)                 
        {
            return $next($request,$response);         
        }   
        else
        {
            return $response->withJson("Usuario no registrado en base de datos", 200);
        }  
    }


}
?>