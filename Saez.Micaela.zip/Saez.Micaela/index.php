<?php
    
    use \Psr\Http\Message\ServerRequestInterface as Request;
    use \Psr\Http\Message\ResponseInterface as Response;

    require_once "./vendor/autoload.php";
    require_once "./Media.php";
    require_once "./usuario.php";
    require_once "./MW.php";
    use \Firebase\JWT\JWT as JWT;

    $config['displayErrorDetails'] = true;
    $config['addContentLengthHeader'] = false;
  
    $app = new \Slim\App(["settings" => $config]);

    $app->post('[/]', function ($request, $response) 
    {
        $datos = $request->getParsedbody();
        $marca = $datos["marca"];
        $color = $datos["color"];
        $precio = $datos["precio"];
        $talle = $datos["talle"];
            
        $obj = new Media($color,$marca,$precio,$talle);
                
        if($obj->Agregar())
        {
            return $response->withJson("Elemento agregado ", 200);    
        }
        else
        {
            return $response->withJson("Error al agregar", 200);
        }
         

    });

    $app->group('/medias', function ()
    {
        $this->get('[/]', function ($request, $response) 
        {
            return $response->withJson(Media::TraerTodos(), 200);                
        });
    });


    $app->group('/usuario', function ()
    {
        $this->post('[/]', function ($request, $response) 
        {
            $datos = $request->getParsedbody();

            $apellido = $datos["apellido"];
            $nombre = $datos["nombre"];
            $clave = $datos["clave"];
            $mail = $datos["email"];
            $perfil = $datos["perfil"];
            $email = $datos["email"];
            $foto = $datos["foto"];

            $obj = new Usuario($nombre, $apellido, $email, $perfil, $foto, $clave);
            if(Usuario::TraerPorEmailClave($email, $clave) != null)                 
            {
                if($obj->Agregar())
                {
                    return $response->withJson("Usuario agregado", 200);
                }     
                else
                {
                    return $response->withJson("No se pudo agregar usuario", 200);
                }         
            }   
            else
            {
                return $response->withJson("Usuario ya registrado", 200);
            }          
            
        });



    });


    $app->get('[/]', function ($request, $response) {
            
        return $response->withJson(Usuario::TraerTodos(), 200);                
    });


    $app->group('/login', function ()
    {
        $this->post('[/]', function ($request, $response) 
        {
            $datos = $request->getParsedbody();
            $clave = $datos["clave"];
            $email = $datos["correo"];

            $payload = array(
                "correo" => $email,
                "clave" => $clave,
            );
            $token = JWT::encode($payload,"miClaveSecreta");

            return $response->withJson($token, 200);
            
        })->add(\MW::class.":VerificarMailClave")->add(\MW::class."::VerificarVacios")->add(\MW::class.":VerificarSeteados");
        
        
        $this->get('[/]', function ($request, $response) 
        {
            $token = $request->getHeader("token")[0];
            
            if(empty($token) || $token === "")
            {
                throw new Exception("El token esta vacio!");
            }

            try{
                $decodificado = JWT::decode(
                    $token,
                    "miClaveSecreta",
                    ["HS256"]
                );
                
                return $response->withJson("Token valido", 200);          
            }
            catch(Exception $e){
                return $response->withJson("Token no valido", 409);
            }
        });
    });



    $app->run();
?>