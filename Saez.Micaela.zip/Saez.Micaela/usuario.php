<?php
include_once "AccesoDatos.php";
class Usuario
{
    public $nombre;
    public $apellido;
    public $foto;
    public $email;
    public $clave;
    public $perfil;

    public function __construct($nombre="",$apellido="",$email="",$perfil="",$foto="",$clave="")
    {
        $this->nombre = $nombre;
        $this->apellido = $apellido;
        $this->email = $email;
        $this->perfil = $perfil;
        $this->foto = $foto;
        $this->clave = $clave;
    }

    public function Agregar()
    {
        $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
        $consulta =$objetoAccesoDato->RetornarConsulta("INSERT into usuarios 
        (nombre, apellido, correo, perfil, foto, clave)
        values (:nombre,:apellido,:email,:perfil,:foto,:clave)");
        $consulta->bindValue(':nombre',$this->nombre,PDO::PARAM_STR);
        $consulta->bindValue(':apellido',$this->apellido,PDO::PARAM_STR);
        $consulta->bindValue(':email', $this->email, PDO::PARAM_STR);
        $consulta->bindValue(':perfil', $this->perfil, PDO::PARAM_STR);
        $consulta->bindValue(':foto', $this->foto, PDO::PARAM_STR);
        $consulta->bindValue(':clave', $this->clave, PDO::PARAM_STR);
        		
        return $consulta->execute();
    }
    public static function TraerTodos()
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios");
		$consulta->execute();			
		return $consulta->fetchAll(PDO::FETCH_ASSOC);		
    }
    public static function TraerPorID($id)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios where id='$id'");
		$consulta->execute();			
		return $consulta->SetFetchMode(PDO::FETCH_INTO, new Usuario);
    }
    
    public static function TraerPorEmailClave($email, $clave)
	{
		$objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso(); 
		$consulta =$objetoAccesoDato->RetornarConsulta("SELECT * from usuarios where correo='$email' and clave='$clave'");
		$consulta->execute();			
        $obj = $consulta->fetchObject("Usuario");
         return $obj;
         
	}


}







?>