<?php

class Usuario
{
    public $nombre;
    public $clave;

    public static function ValidarUsuario($request, $response, $next)
    {    
        if($request->isGet())
        {
            $response->getBody()->write("<br>El request de grupo es un GET");
        }
        else if ($request->isPost())
        {
            $respuestasArray = $request->GetParsedBody();
    
            require_once("AccesoDatos.php");
            require_once("usuario.php");
            $objetoAccesoDato = AccesoDatos::dameUnObjetoAcceso();
            $consulta = $objetoAccesoDato->RetornarConsulta("select * FROM usuarios where clave=:clave and nombre=:nombre");
            $clave = $respuestasArray["clave"];
            $nombre = $respuestasArray["nombre"];
            $consulta->bindParam(":clave", $clave, PDO::PARAM_STR);
            $consulta->bindParam(":nombre", $nombre, PDO::PARAM_STR);
            $consulta->Execute();
            $usuarios = $consulta->Fetch();
            
            if ($usuarios > 0) 
            {
                $response->getBody()->write("<br>Bienvenidx ". $nombre);  
                $response->getBody()->write("<br>El request de grupo es un POST");
                return $next($request,$response);
            }else
            {
                $response->getBody()->write("<br>Sin permiso/no registrado en base de datos");
            }
            /*if($respuestasArray["perfil"] == "admin")
            {
                $response->getBody()->write("<br>Bienvenidx ". $respuestasArray["nombre"]);  
                $response->getBody()->write("<br>El request de grupo es un POST");  
            }
            else
            {
                $response->getBody()->write("<br>Sin permiso");
            }*/
        }
        
        return $response;
    }
}