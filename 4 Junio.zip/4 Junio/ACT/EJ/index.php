<?php
use \Psr\Http\Message\ServerRequestInterface as Request;
use \Psr\Http\Message\ResponseInterface as Response;

$config['displayErrorDetails'] = true;
$config['addContentLengthHeader'] = false;

require_once './vendor/autoload.php';
require_once 'usuario.php';

$app = new \Slim\App(["settings" => $config]);

$app->get('[/]', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>GET");
    return $response;

});

$app->add(function ($request, $response, $next) {    
    $response->getBody()->write("Antes a nivel de APP");
    $response = $next($request, $response);
    $response->getBody()->write("<br>Despues a nivel de APP");    
    return $response;
});

$app->put('/param', function (Request $request, Response $response) {    
    $response->getBody()->write("<br>Con param");
    return $response;
})->add(function ($request, $response, $next) {    
    $response->getBody()->write("<br>Antes con param");
    $response = $next($request, $response);
    $response->getBody()->write("<br>Despues con param");    
    return $response;
});


$app->group('/credenciales', function () {

    $this->get('[/]', function ($request, $response) {
        $response->getBody()->write("<br>Estoy en GET de grupo");
    });
 
    $this->post('[/]', function ($request, $response) {      
        $response->getBody()->write("<br>Estoy en POST de grupo");
    });
      
})->add(\Usuario::class."::ValidarUsuario");



$app->run();


?>