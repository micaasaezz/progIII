<?php
$valor=$_POST["nombre"];
$persona = new StdClass();
$persona->nombre = $valor;
echo json_encode($persona);

?>