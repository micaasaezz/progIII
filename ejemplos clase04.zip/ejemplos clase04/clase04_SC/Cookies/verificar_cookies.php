<?php

var_dump($_COOKIE);

?>
<a href="../verificar_cookies.php" >Ir a un directorio superior</a>
<br/>
<a href="../index.html" >Volver al Inicio</a>