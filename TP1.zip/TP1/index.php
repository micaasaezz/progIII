<?php

include "Persona.php";
include "Empleado.php";
include "Fabrica.php";

$empleado = new Empleado("Mariano","Juarez",19786442,'m',1090,12000,"tarde");
$empleado2 = new Empleado("Claudia","Ramirez",24783955,'f',1278,15000,"mañana");
$empleado3 = new Empleado("Roberto","Perez",17839255,'m',1390,15700,"mañana");
$empleado4 = new Empleado("Mariela","Rios",26443987,'f',1134,13500,"tarde");
$empleado5 = new Empleado("Luciano","Martinez",28654225,'m',1190,15200,"mañana");
$empleadoSobrante = new Empleado("Manuel","Montero",27555342,'m',1264,13300,"tarde");


echo "TESTEO JERARQUIA DE CLASES<br><br>";
echo "Apellido, Nombre - DNI - sexo - legajo - sueldo - turno<br>";
echo $empleado->ToString()." - ".$empleado->Hablar(array("Italiano", "Aleman", "Ingles"));
echo"<br>" . $empleado2->ToString()." - ".$empleado->Hablar(array("Portugues", "Italiano"));


echo "<br><br><br>TESTEO CLASE FABRICA<br><br>";
echo "---Creo una fabrica con 4 empleados---<br>";
$fabrica = new Fabrica("Filgo S.A.");
$fabrica->AgregarEmpleado($empleado);
$fabrica->AgregarEmpleado($empleado2);
$fabrica->AgregarEmpleado($empleado3);
$fabrica->AgregarEmpleado($empleado4);
echo $fabrica->ToString();

echo "<br>---Agrego empleado repetido---<br>";
$fabrica->AgregarEmpleado($empleado2);
echo $fabrica->ToString();

echo "<br>---Agrego 2 empleados mas---<br>";
$fabrica->AgregarEmpleado($empleado5);
$fabrica->AgregarEmpleado($empleadoSobrante);
echo $fabrica->ToString();

echo "<br>---Elimino un empleado---<br>";
$fabrica->EliminarEmpleado($empleado);
echo $fabrica->ToString();




?>