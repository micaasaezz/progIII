<?php
include_once "Empleado.php";
class Fabrica
{
    private $_cantidadMaxima;
    private $_empleados;
    private $_razonSocial;

    public function __construct($razonSocial)
    {
        $this->_razonSocial = $razonSocial;
        $this->_empleados = array();
        $this->_cantidadMaxima = 5;
    }

    public function AgregarEmpleado($emp)
    {
        if(count($this->_empleados) < $this->_cantidadMaxima)
        {
            array_push($this->_empleados, $emp);
            $this->EliminarEmpleadoRepetido();
            return true;
        }
        return false;
    }
    public function CalcularSueldos()
    {
        $ret = 0;
        foreach($this->_empleados as $emp)
        {
            $ret += $emp->GetSueldo();
        }
        return $ret;
    }
    public function EliminarEmpleado($emp)
    {
        for($i=0; $i< count($this->_empleados); $i++)
        {
            if($this->_empleados[$i] == $emp)
            {
                unset($this->_empleados[$i]);
                break;
            }
        }
        return true;
    }
    private function EliminarEmpleadoRepetido()
    {
        $empleadosAux = array_unique($this->_empleados, SORT_REGULAR);
        $this->_empleados = $empleadosAux;
    }
    
    public function ToString()
    {
        $ret = $this->_razonSocial." - Cant. empleados: ".count($this->_empleados)." - Max: ".$this->_cantidadMaxima."<br>";
        $ret .= "Total sueldos: ".$this->CalcularSueldos()."<br>";
        foreach($this->_empleados as $emp)
        {
            $ret .= $emp->ToString(). "<br>";
        }
        return $ret;
    }


}

?>